import sys

import requests

from naive.NView import BaseDialog
from pathlib import Path
from PySide6 import QtGui, QtCore, QtWidgets
from io import BytesIO
from naive.NUtils.NFunc import threadFunc
import logging

try:
    from PIL import Image as PILImage, ImageQt

    HAS_PIL = True
except ImportError:
    HAS_PIL = False
try:
    import requests

    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


class Image(BaseDialog):
    load_signal = QtCore.Signal(QtGui.QPixmap)

    def __init__(self, parent: QtWidgets.QWidget, path: str):
        super().__init__(parent)
        self.setWindowTitle(Path(path).name)
        self.resize(parent.size())
        self.speed_up: bool = False
        self.img_reset: bool = False
        self.zoom: float = 0
        self.image_standard: QtCore.QPoint = QtCore.QPoint(0, 0)
        self.left_mouse_click: bool = False
        self.left_mouse_click_pos: None | QtCore.QPointF = None
        self._show_img_data: None | QtGui.QPixmap = None
        self.load_signal.connect(self.setImage)
        self.openImage(path)

    def setImage(self, img: QtGui.QPixmap):
        self._show_img_data = img
        self.update()
        self.exec()

    @QtCore.Slot(QtGui.QPixmap)
    @threadFunc()
    def openImage(self, path: str):
        try:
            if not HAS_PIL:
                # TODO: pip 修改 提示
                raise ImportError("PIL is not installed")
            if path.startswith(("http://", "https://", "file://")):
                if not HAS_REQUESTS:
                    # TODO: pip 修改 提示
                    raise ImportError("requests is not installed")
                file_content = requests.get(path, timeout=5).content
            else:
                file_content = Path(path).read_bytes()
            iio = BytesIO(file_content)
            with PILImage.open(iio) as image:
                # noinspection PyTypeChecker
                self.load_signal.emit(QtGui.QPixmap(ImageQt.ImageQt(image)))
        except Exception as e:
            logging.error(e, exc_info=True)
            print(e)

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        brush = QtGui.QPainter()
        brush.begin(self)
        brush.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        self.__showFile(brush)
        brush.end()

    def __showFile(self, brush: QtGui.QPainter) -> None:
        if not self._show_img_data: return
        if not self.zoom or self.img_reset: self.__adaptZoom(True)
        s_x = int(self._show_img_data.width() / self.zoom)
        s_y = int(self._show_img_data.height() / self.zoom)
        rect = QtCore.QRect(self.image_standard.x(), self.image_standard.y(), s_x, s_y)
        brush.drawPixmap(rect, self._show_img_data)

    def __adaptZoom(self, auto=False):
        if not self._show_img_data: return
        if self.height() <= (self.width() * self._show_img_data.height()) / self._show_img_data.width():
            self.zoom = self._show_img_data.height() / self.height()
        else:
            self.zoom = self._show_img_data.width() / self.width()
        self.image_standard = QtCore.QPoint(
            int((self.width() - (self._show_img_data.width() / self.zoom)) / 2),
            int((self.height() - (self._show_img_data.height() / self.zoom)) / 2)
        )
        if not auto:
            self.update()

    def wheelEvent(self, event) -> None:
        if not self._show_img_data: return
        angle = event.angleDelta() / 8
        angle_y = angle.y()
        exclude = (event.position() - self.image_standard) * self.zoom
        if angle_y > 0:
            pantograph_ratio = 0.7 if self.speed_up else 0.95

            if self.zoom * pantograph_ratio > 0.001:
                self.zoom *= pantograph_ratio
        else:
            pantograph_ratio = 1.3 if self.speed_up else 1.05

            if self.zoom * pantograph_ratio < 100:
                self.zoom *= pantograph_ratio
        self.image_standard = (event.position() - exclude / self.zoom).toPoint()
        self.update()

    def mousePressEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.left_mouse_click_pos = event.position()
            self.left_mouse_click = True
        self.update()

    def mouseMoveEvent(self, event: QtGui.QMouseEvent) -> None:
        self.setFocus()
        if self.left_mouse_click:
            sx = self.left_mouse_click_pos - event.position()
            self.image_standard = QtCore.QPoint(self.image_standard.x() - sx.x(), self.image_standard.y() - sx.y())
            self.left_mouse_click_pos = event.position()
        self.update()

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent) -> None:
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.left_mouse_click = False

    def keyPressEvent(self, event: QtGui.QKeyEvent) -> None:
        if event.key() == QtCore.Qt.Key.Key_Space:
            self.__adaptZoom()
        if event.key() == QtCore.Qt.Key.Key_Shift:
            self.speed_up = True

    def keyReleaseEvent(self, event: QtGui.QKeyEvent) -> None:
        if event.key() == QtCore.Qt.Key.Key_Shift:
            self.speed_up = False
