from naive.NUtils.NMetaClass import NMetaClass

try:
    from plyer import notification

    HAS_TOAST = True
except ImportError:
    HAS_TOAST = False


class SystemToast(metaclass=NMetaClass):
    ICON = None

    def send(self,
             title: str,
             message: str,
             app_icon: str = None,
             timeout: int = 15):
        if not HAS_TOAST:
            # TODO: pip 修改
            raise ImportError('Please install plyer')
        if not app_icon:
            app_icon = self.ICON
        print(app_icon)
        notification.notify(
            title=title,
            message=message,
            app_icon=app_icon,
            timeout=timeout,
        )
