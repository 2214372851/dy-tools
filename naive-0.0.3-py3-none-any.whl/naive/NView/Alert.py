from PySide6 import QtGui, QtCore, QtWidgets
from naive.NView import BaseVBoxLayout
from naive.NCore.Core import AlertType


class Alert(QtWidgets.QFrame):
    def __init__(self, title: str, content: str,
                 icon: str | QtGui.QPixmap = 'Icons:attention.svg',
                 style_type: AlertType = AlertType.default):
        super().__init__()
        self.setObjectName("main-alert")
        self.setProperty("type", style_type.value)
        self.title = title
        self.content = content
        self.icon = icon
        self.setupUi()

    def setupUi(self):
        self.setLayout(BaseVBoxLayout())
        self.header()
        self.body()
        self.layout().setStretch(0, 1)
        self.layout().setStretch(1, 6)

    def header(self):
        head = QtWidgets.QWidget()
        head.setLayout(QtWidgets.QHBoxLayout())
        head.layout().setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        icon = QtWidgets.QLabel()
        if isinstance(self.icon, str):
            icon.setPixmap(QtGui.QPixmap(self.icon))
        elif isinstance(self.icon, QtGui.QPixmap):
            icon.setPixmap(self.icon)
        icon.setFixedSize(24, 24)
        head.layout().addWidget(icon)
        title = QtWidgets.QLabel(self.title)
        title.setObjectName("main-alert-title")
        head.layout().addWidget(title)
        self.layout().addWidget(head)

    def body(self):
        body = QtWidgets.QWidget()
        body.setLayout(QtWidgets.QHBoxLayout())
        body.layout().setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
        interval = QtWidgets.QWidget()
        interval.setFixedWidth(24)
        body.layout().addWidget(interval)
        content = QtWidgets.QLabel(self.content)
        content.setObjectName("main-alert-content")
        body.layout().addWidget(content)
        self.layout().addWidget(body)
